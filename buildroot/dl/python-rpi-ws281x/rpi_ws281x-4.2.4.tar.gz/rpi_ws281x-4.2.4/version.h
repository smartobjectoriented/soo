#ifndef __VERSION_H__
#define __VERSION_H__

#define VERSION_MAJOR 1
#define VERSION_MINOR 1
#define VERSION_MICRO 0

#endif /* __VERSION_H__ */
