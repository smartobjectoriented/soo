# Master version for Pillow
__version__ = "7.0.0"
