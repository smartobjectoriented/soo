***************
NumPy internals
***************

.. toctree::

   internals.code-explanations
   alignment

.. automodule:: numpy.doc.internals
